#!/usr/bin/env bash

java -jar quilt-installer.jar install server 1.19.2 --download-server

